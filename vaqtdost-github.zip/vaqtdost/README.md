# VaqtDost 2.0

O'quvchilar uchun dars jadvali va vazifa rejalashtiruvchi veb-ilova (Hakmun Academy).

## Fayllar
- `index.html` — butun ilova (dizayn + mantiq), bitta fayl
- `supabase_setup.sql` — ustoz/o'quvchi sinflari uchun baza jadvali va funksiyalar

## Bazani ulash
1. supabase.com da loyiha oching, SQL Editor'da `supabase_setup.sql` ni ishga tushiring.
2. Project Settings → API dan *Project URL* va *anon public key* ni oling.
3. `index.html` boshidagi `SB_URL` va `SB_KEY` o'rniga qo'ying.

## Joylash
Netlify yoki GitHub Pages: `index.html` ni joylang.
