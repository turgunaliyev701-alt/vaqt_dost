-- Supabase > SQL Editor ga to'liq qo'yib, Run bosing
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.classes(
  code text primary key,
  name text not null,
  pw_hash text not null,
  owner_key text not null,
  tasks jsonb not null default '[]',
  created_at timestamptz default now()
);
alter table public.classes enable row level security; -- policy yo'q: jadvalga to'g'ridan-to'g'ri kirish yopiq

create or replace function public.create_class(p_name text, p_password text) returns jsonb
language plpgsql security definer set search_path=public,extensions as $$
declare v_code text; v_key text;
begin
  if length(p_password)<4 or length(trim(p_name))=0 then raise exception 'Nom yoki parol noto''g''ri'; end if;
  loop
    v_code:='VD-'||upper(substr(encode(gen_random_bytes(3),'hex'),1,4));
    exit when not exists(select 1 from classes where code=v_code);
  end loop;
  v_key:=encode(gen_random_bytes(16),'hex');
  insert into classes(code,name,pw_hash,owner_key) values(v_code,left(p_name,80),crypt(p_password,gen_salt('bf')),v_key);
  return jsonb_build_object('code',v_code,'owner_key',v_key);
end$$;

create or replace function public.get_class(p_code text, p_password text) returns jsonb
language plpgsql security definer set search_path=public,extensions as $$
declare r classes;
begin
  select * into r from classes where code=upper(p_code);
  if not found or r.pw_hash<>crypt(p_password,r.pw_hash) then raise exception 'Kod yoki parol noto''g''ri'; end if;
  return jsonb_build_object('name',r.name,'tasks',r.tasks);
end$$;

create or replace function public.set_tasks(p_code text, p_owner_key text, p_tasks jsonb) returns void
language plpgsql security definer set search_path=public,extensions as $$
begin
  update classes set tasks=p_tasks where code=p_code and owner_key=p_owner_key;
  if not found then raise exception 'Ruxsat yo''q'; end if;
end$$;

create or replace function public.delete_class(p_code text, p_owner_key text) returns void
language plpgsql security definer set search_path=public,extensions as $$
begin
  delete from classes where code=p_code and owner_key=p_owner_key;
end$$;
